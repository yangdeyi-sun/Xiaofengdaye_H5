import { AUDIO_ALIASES, AUDIO_CUES } from '../infrastructure/AudioCatalog';
import type { SoundHandle } from './Platform';
import { platform } from './Platform';

/** 小游戏同时存在的音频实例数量有限，短音效并发上限 */
const MAX_SHOTS = 8;

/** 音乐、环境声、天气声的循环层，切换时交叉淡入淡出。底层播放器由平台层提供。 */
class LoopLayer {
  private audio: SoundHandle | null = null;
  private path = '';
  private revision = 0;
  private fading = false;
  private desiredVolume = 0;
  private readonly retiring = new Set<SoundHandle>();

  set(path: string, volume: number, active: boolean): void {
    const wanted = active ? path : '';
    this.desiredVolume = Math.max(0, Math.min(1, volume));
    if (wanted !== this.path) {
      const old = this.audio;
      const oldVolume = old?.volume ?? 0;
      this.revision++;
      const revision = this.revision;
      this.path = wanted;
      if (wanted.length === 0) {
        old?.dispose();
        this.retiring.forEach((audio) => audio.dispose());
        this.retiring.clear();
        this.audio = null;
        this.fading = false;
        return;
      }
      if (old !== null) this.retiring.add(old);
      const audio = platform().audio.create(wanted, true);
      audio.volume = 0;
      this.audio = audio;
      this.fading = true;
      void audio.play().catch(() => { /* A user gesture will retry playback. */ });
      let step = 0;
      const timer = setInterval(() => {
        if (revision !== this.revision) {
          clearInterval(timer);
          if (old !== null) { old.dispose(); this.retiring.delete(old); }
          return;
        }
        step++;
        audio.volume = this.desiredVolume * Math.min(1, step / 15);
        if (old !== null) old.volume = oldVolume * Math.max(0, 1 - step / 15);
        if (step >= 15) {
          clearInterval(timer);
          old?.dispose();
          if (old !== null) this.retiring.delete(old);
          this.fading = false;
        }
      }, 60);
      return;
    }
    if (this.audio !== null) {
      if (!this.fading) this.audio.volume = this.desiredVolume;
      if (active && this.audio.paused) void this.audio.play().catch(() => {});
    }
  }

  stop(): void {
    this.revision++;
    this.fading = false;
    this.audio?.dispose();
    this.retiring.forEach((audio) => audio.dispose());
    this.retiring.clear();
    this.audio = null;
    this.path = '';
  }
}

export class BrowserAudioService {
  sfxOn = true;
  musicOn = true;
  vibrateOn = true;
  private foreground = false;
  private permitted = false;
  private musicPath = '';
  private normalMusicPath = '';
  private ambiencePath = '';
  private weatherPath = '';
  private threatLevel = 0;
  private duckUntil = 0;
  private musicVolume = 0.8;
  private ambientVolume = 0.65;
  private effectsVolume = 0.75;
  private readonly music = new LoopLayer();
  private readonly ambience = new LoopLayer();
  private readonly weather = new LoopLayer();
  private readonly shots = new Set<SoundHandle>();
  private readonly lastPlay = new Map<string, number>();
  private readonly lastVariant = new Map<string, number>();
  private lastCombatPlay = 0;
  private released = false;

  unlock(): void {
    if (this.released) return;
    this.foreground = true;
    this.syncLayers();
  }

  play(name: string): void {
    if (this.released || !this.sfxOn || !this.foreground || !this.permitted) return;
    const key = AUDIO_ALIASES[name] ?? name;
    const cue = AUDIO_CUES[key];
    if (cue === undefined) return;
    const now = Date.now();
    if (key.startsWith('alert_')) {
      this.duckUntil = now + 2200;
      this.syncLayers();
    }
    const combat = ['guard_attack', 'bee_hurt', 'wasp_attack', 'web_trap', 'web_clear', 'moth_chew_loop', 'bear_step', 'bear_swipe'].includes(key);
    if (combat && now - this.lastCombatPlay < 450) return;
    const highFrequency = ['collect_flower', 'queen_lay_egg', 'hatch_shell', 'forager_pickup', 'forager_deliver'].includes(key);
    const cooldown = highFrequency ? Math.max(180, cue.cooldownMs) : cue.cooldownMs;
    const previous = this.lastPlay.get(key);
    if (previous !== undefined && now - previous < cooldown) return;
    let variant = Math.floor(Math.random() * cue.files.length);
    if (cue.files.length > 1 && variant === this.lastVariant.get(key)) variant = (variant + 1) % cue.files.length;
    this.lastPlay.set(key, now);
    this.lastVariant.set(key, variant);
    if (combat) this.lastCombatPlay = now;
    if (this.shots.size >= MAX_SHOTS) return;
    const audio = platform().audio.create(cue.files[variant], false);
    audio.volume = Math.max(0, Math.min(1, cue.volume * this.effectsVolume));
    this.shots.add(audio);
    const release = (): void => { this.shots.delete(audio); audio.dispose(); };
    audio.onFinish(release);
    void audio.play().catch(release);
  }

  setScene(screen: string, region: string, hive: boolean, weather: string): void {
    if (this.released) return;
    this.permitted = screen === 'home' || screen === 'game';
    const safeRegion = ['meadow', 'alpine', 'rainy', 'drought', 'rooftop'].includes(region) ? region : 'meadow';
    this.normalMusicPath = `audio/v1/music/bgm_${screen === 'home' ? 'home' : safeRegion}.mp3`;
    this.musicPath = screen === 'game' && this.threatLevel > 0
      ? `audio/v1/music/bgm_${safeRegion === 'drought' ? 'alpine' : 'drought'}.mp3`
      : this.normalMusicPath;
    const ambience = hive || screen === 'home' ? 'hive' : (safeRegion === 'rainy' ? 'wetland' : safeRegion);
    this.ambiencePath = `audio/v1/ambience/amb_${ambience}.mp3`;
    this.weatherPath = screen === 'game' && !hive && ['rain', 'snow', 'autumn'].includes(weather)
      ? `audio/v1/weather/weather_${weather}.mp3` : '';
    if (!this.permitted) this.stopShots();
    this.syncLayers();
  }

  setVolumes(music: number, ambient: number, effects: number): void {
    this.musicVolume = Math.max(0, Math.min(1, music));
    this.ambientVolume = Math.max(0, Math.min(1, ambient));
    this.effectsVolume = Math.max(0, Math.min(1, effects));
    this.syncLayers();
  }

  setThreatLevel(level: number): void { this.threatLevel = Math.max(0, Math.floor(level)); }
  setSfx(on: boolean): void { this.sfxOn = on; if (!on) this.stopShots(); this.syncLayers(); }
  setMusic(on: boolean): void { this.musicOn = on; this.syncLayers(); }
  resumeMusic(): void { if (!this.released) { this.foreground = true; this.syncLayers(); } }
  pauseMusic(): void { this.foreground = false; this.stopShots(); this.syncLayers(); }

  tick(): void {
    if (this.duckUntil > 0 && Date.now() >= this.duckUntil) {
      this.duckUntil = 0;
      this.syncLayers();
    }
  }

  vibrate(ms: number): void {
    if (!this.released && this.vibrateOn) platform().vibrate(ms);
  }

  private syncLayers(): void {
    if (this.released) return;
    const active = this.foreground && this.permitted;
    const duck = Date.now() < this.duckUntil ? 0.42 : 1;
    this.music.set(this.musicPath, 0.4 * this.musicVolume * duck, active && this.musicOn);
    this.ambience.set(this.ambiencePath, 0.28 * this.ambientVolume * duck, active && this.sfxOn);
    this.weather.set(this.weatherPath, 0.24 * this.ambientVolume * duck, active && this.sfxOn && this.weatherPath.length > 0);
  }

  private stopShots(): void {
    this.shots.forEach((audio) => audio.dispose());
    this.shots.clear();
  }

  release(): void {
    if (this.released) return;
    this.released = true;
    this.foreground = false;
    this.stopShots();
    this.music.stop();
    this.ambience.stop();
    this.weather.stop();
  }
}
